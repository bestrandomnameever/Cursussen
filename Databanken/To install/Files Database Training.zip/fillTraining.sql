alter session  set NLS_DATE_FORMAT='DD-MM-YYYY';

REM ================================================
REM Disable constraints (maakt vullen gemakkelijker)
REM ================================================

alter table employees disable primary key cascade;
alter table employees disable constraint E_CHIEF_FK;
alter table employees disable constraint E_DEP_FK;
alter table history disable constraint H_DEP_FK;

REM ==============================================
REM Table EMPLOYEES (EMPLOYEEID,LASTNAME,FIRSTNAME,SERVICE,CHIEF
REM                   ,DATEOFBIRTH,SALARY,COMMENTS,DEPARTMENT)
REM ==============================================

truncate table employees;

insert into employees values(7369,'SMITH','JOHN','TRAINER',7902,'17-12-1985',800,NULL,20);
insert into employees values(7499,'ELDERS','TOM','SALESPERSON',7698,'20-02-1981',1600,300,30);
insert into employees values(7521,'ZUCKERMAN','ANNE','SALESPERSON',7698,'22-02-1982',1250,500,30);
insert into employees values(7566,'ANDERSON','MIKE','MANAGER',7839,'02-04-1987',2975,NULL,20);
insert into employees values(7654,'PARKER','POLLY','SALESPERSON',7698,'28-09-1976',1250,1400,30);
insert into employees values(7698,'BARRYMORE','MARIE','MANAGER',7839,'01-11-1983',2850,NULL,30);
insert into employees values(7782,'JOHNSON','AUDREY','MANAGER',7839,'09-06-1985',2450,NULL,10);
insert into employees values(7788,'DICKENS','CHARLES','TRAINER',7566,'26-11-1979',3000,NULL,20);
insert into employees values(7839,'KINGS','WILL','CEO',NULL,'17-11-1972',5000,NULL,10);
insert into employees values(7844,'DAVENPORT','JENNY','SALESPERSON',7698,'28-09-1988',1500,0,30);
insert into employees values(7876,'ADAMS','MARTHA','TRAINER',7788,'30-12-1986',1100,NULL,20);
insert into employees values(7900,'JACOBS','CHRISTEL','ACCOUNTANT',7698,'03-12-1989',800,NULL,30);
insert into employees values(7902,'PETERSON','KATY','TRAINER',7566,'13-02-1979',3000,NULL,20);
insert into employees values(7934,'WILLIAMS','JERRY','ACCOUNTANT',7782,'23-01-1982',1300,NULL,10);

alter table employees enable primary key;

REM =========================================
REM Table DEPARTMENTS (DEPARTMENTID,NAME,LOCATION,HEAD)
REM =========================================

truncate table departments;

insert into departments values (10,'HEAD OFFICE','BRUSSELS',7782);
insert into departments values (20,'TRAINING CENTER','GHENT',7566);
insert into departments values (30,'SALES','ANTWERP',7698);
insert into departments values (40,'ADMINISTRATION','OSTEND',7839);

REM =================================================
REM Table SCALES (SCALEID,LOWERLIMIT,UPPERLIMIT,BONUS)
REM =================================================

truncate table scales;

insert into scales values (1,   700,1200,    0);
insert into scales values (2,  1201,1400,   50);
insert into scales values (3,  1401,2000,  100);
insert into scales values (4,  2001,3000,  200);
insert into scales values (5,  3001,9999,  500);

REM ===============================================
REM Table COURSES (COURSEID,DESCRIPTION,TYPE,LENGTH)
REM ===============================================

alter table courses disable primary key cascade;
truncate table courses;

insert into courses values('S02','Introduction SQL','GEN',4);
insert into courses values('OAG','Oracle for system engineers','GEN',1);
insert into courses values('JAV','Java for Oracle developers','BLD',4);
insert into courses values('PLS','Introduction PL/SQL','BLD',1);
insert into courses values('XML','XML voor Oracle developers','BLD',2);
insert into courses values('ERM','Datamodelling with ERM','DSG',3);
insert into courses values('PMT','Process modelling techniques','DSG',1);
insert into courses values('RSO','Relational database design','DSG',2);
insert into courses values('PRO','Prototyping','DSG',5);
insert into courses values('GEN','Introduction datawarehousing design','DSG',4);

alter table courses enable primary key;

REM =====================================================
REM Table VERSIONS (COURSEID,STARTDATE,TRAINER,LOCATION)
REM =====================================================

alter table versions disable primary key cascade;
truncate table versions;

insert into versions   values ('S02','12-04-2014',7902,'BERCHEM'  );
insert into versions   values ('OAG','10-08-2014',7566,'AALST'   );
insert into versions   values ('S02','04-10-2014',7369,'ANDERLECHT');
insert into versions   values ('S02','13-12-2014',7369,'BERCHEM'  );
insert into versions   values ('JAV','13-12-2014',7566,'ANDERLECHT');
insert into versions   values ('XML','03-02-2015',7369,'BERCHEM'  );
insert into versions   values ('JAV','01-02-2015',7876,'BERCHEM'  );
insert into versions   values ('PLS','11-09-2015',7788,'BERCHEMN'  );
insert into versions   values ('XML','18-09-2015',NULL,'ANDERLECHT');
insert into versions   values ('OAG','27-09-2015',7902,'BERCHEM'  );

insert into versions   values ('ERM','15-01-2016',NULL, NULL       );
insert into versions   values ('PRO','19-02-2016',NULL,'BERCHEM'  );
insert into versions   values ('RSO','24-02-2016',7788,'AALST'   );

alter table versions enable primary key;

REM ==========================================================
REM Table ENROLLMENTS (LEARNER,COURSEID,STARTDATE,EVALUATION)
REM ==========================================================

truncate table enrollments;

insert into enrollments values (7499,'S02','12-04-2014',4   );
insert into enrollments values (7934,'S02','12-04-2014',5   );
insert into enrollments values (7698,'S02','12-04-2014',4   );
insert into enrollments values (7876,'S02','12-04-2014',2   );
insert into enrollments values (7788,'S02','04-10-2014',NULL);
insert into enrollments values (7839,'S02','04-10-2014',3   );
insert into enrollments values (7902,'S02','04-10-2014',4   );
insert into enrollments values (7902,'S02','13-12-2014',NULL);
insert into enrollments values (7698,'S02','13-12-2014',NULL);
insert into enrollments values (7521,'OAG','10-08-2014',4   );
insert into enrollments values (7900,'OAG','10-08-2014',4   );
insert into enrollments values (7902,'OAG','10-08-2014',5   );
insert into enrollments values (7844,'OAG','27-09-2015',5   );
insert into enrollments values (7499,'JAV','13-12-2014',2   );
insert into enrollments values (7782,'JAV','13-12-2014',5   );
insert into enrollments values (7876,'JAV','13-12-2014',5   );
insert into enrollments values (7788,'JAV','13-12-2014',5   );
insert into enrollments values (7839,'JAV','13-12-2014',4   );
insert into enrollments values (7566,'JAV','01-02-2015',3   );
insert into enrollments values (7788,'JAV','01-02-2015',4   );
insert into enrollments values (7698,'JAV','01-02-2015',5   );
insert into enrollments values (7900,'XML','03-02-2015',4   );
insert into enrollments values (7499,'XML','03-02-2015',5   );
insert into enrollments values (7566,'PLS','11-09-2015',NULL);
insert into enrollments values (7499,'PLS','11-09-2015',NULL);
insert into enrollments values (7876,'PLS','11-09-2015',NULL);

REM =============================================================
REM TAble HISTORY
REM (EMPLOYEEID,STARTYEAR,STARTDATE,ENDDATE,DEPARTMENTID,SALARY,REMARKS)
REM =============================================================

alter table history disable primary key cascade;
truncate table history;

insert into history values (7369,2015,'01-01-2015','01-02-2015',40, 950,'');
insert into history values (7369,2015,'01-02-2015', NULL,20, 800,'Change to trainings, with change of salary 150');
--                          ============================================
insert into history values (7499,2003,'01-06-2003','01-07-2004',30,1000,'');
insert into history values (7499,2004,'01-07-2004','01-12-2008',30,1300,'');
insert into history values (7499,2008,'01-12-2008','01-10-2010',30,1500,'');
insert into history values (7499,2010,'01-10-2010','01-11-2014',30,1700,'');
insert into history values (7499,2014,'01-11-2014', NULL,30,1600,'Did not meet the targets; salary is lowered');
--                          ============================================
insert into history values (7521,2001,'01-10-2001','01-08-2002',20,1000,'');
insert into history values (7521,2002,'01-08-2002','01-01-2004',30,1000,'Change to sales departement on own request');
insert into history values (7521,2004,'01-01-2004','15-12-2007',30,1150,'');
insert into history values (7521,2007,'15-12-2007','01-10-2009',30,1250,'');
insert into history values (7521,2009,'01-10-2009','01-10-2012',20,1250,'');
insert into history values (7521,2012,'01-10-2012','01-02-2015',30,1300,'');
insert into history values (7521,2015,'01-02-2015', NULL,30,1250,'');
--                          ============================================
insert into history values (7566,1997,'01-01-1997','01-12-1997',20, 900,'');
insert into history values (7566,1997,'01-12-1997','15-08-1999',20, 950,'');
insert into history values (7566,1999,'15-08-1999','01-01-2001',30,1000,'Not suitable as trainer; goes to sales!');
insert into history values (7566,2001,'01-01-2001','01-07-2001',30,1175,'Sales isnt a big succes either');
insert into history values (7566,2001,'01-07-2001','15-03-2002',10,1175,'');
insert into history values (7566,2002,'15-03-2002','01-04-2002',10,2200,'');
insert into history values (7566,2002,'01-04-2002','01-06-2004',10,2300,'');
insert into history values (7566,2004,'01-06-2004','01-07-2007',40,2300,'From the head office to administration');
insert into history values (7566,2007,'01-07-2007','01-11-2007',40,2450,'');
insert into history values (7566,2007,'01-11-2007','01-09-2009',20,2600,'Back to trainings as head of trainings');
insert into history values (7566,2009,'01-09-2009','01-03-2010',20,2550,'');
insert into history values (7566,2010,'01-03-2010','15-10-2014',20,2750,'');
insert into history values (7566,2014,'15-10-2014',NULL,20,2975,'');
--                          ============================================
insert into history values (7654,2014,'01-01-2014','15-10-2014',30,1100,'Senior sales person');
insert into history values (7654,2014,'15-10-2014', NULL,30,1250,'Does not fulfill expectations');
--                          ============================================
insert into history values (7698,1997,'01-06-1997','01-01-1998',30, 900,'');
insert into history values (7698,1998,'01-01-1998','01-01-1999',30,1275,'');
insert into history values (7698,1999,'01-01-1999','15-04-2000',30,1500,'');
insert into history values (7698,2000,'15-04-2000','01-01-2001',30,2100,'');
insert into history values (7698,2001,'01-01-2001','15-10-2004',30,2200,'');
insert into history values (7698,2004,'15-10-2004',NULL,30,2850,'Promoted to head of sales');
--                          ============================================
insert into history values (7782,2003,'01-07-2003',NULL,10,2450,'Hired as manager in the head office');
--                          ============================================
insert into history values (7788,1997,'01-07-1997','01-01-1998',20, 900,'');
insert into history values (7788,1998,'01-01-1998','15-04-2000',20, 950,'');
insert into history values (7788,2000,'15-04-2000','01-06-2000',40, 950,'Change to administration');
insert into history values (7788,2000,'01-06-2000','15-04-2001',40,1100,'');
insert into history values (7788,2001,'15-04-2001','01-05-2001',20,1100,'');
insert into history values (7788,2001,'01-05-2001','15-02-2002',20,1800,'');
insert into history values (7788,2002,'15-02-2002','01-12-2004',20,1250,'Doesnt meet the targets. Salary is lowered');
insert into history values (7788,2004,'01-12-2004','15-10-2006',20,1350,'');
insert into history values (7788,2006,'15-10-2006','01-01-2013',20,1400,'');
insert into history values (7788,2013,'01-01-2013','01-01-2014',20,1700,'');
insert into history values (7788,2014,'01-01-2014','01-07-2014',20,1800,'');
insert into history values (7788,2014,'01-07-2014','01-06-2015',20,1800,'');
insert into history values (7788,2015,'01-06-2015',NULL,20,3000,'');
--                          ============================================
insert into history values (7839,1997,'01-01-1997','01-08-1997',30,1000,'Founder and first employee of the company');
insert into history values (7839,1997,'01-08-1997','15-05-1999',30,1200,'');
insert into history values (7839,1999,'15-05-1999','01-01-2000',30,1500,'');
insert into history values (7839,2000,'01-01-2000','01-07-2000',30,1750,'');
insert into history values (7839,2000,'01-07-2000','01-11-2000',10,2000,'Head office was founded');
insert into history values (7839,2000,'01-11-2000','01-02-2001',10,2200,'');
insert into history values (7839,2001,'01-02-2001','15-06-2004',10,2500,'');
insert into history values (7839,2004,'15-06-2004','01-12-2008',10,2900,'');
insert into history values (7839,2008,'01-12-2008','01-09-2010',10,3400,'');
insert into history values (7839,2010,'01-09-2010','01-10-2012',10,4200,'');
insert into history values (7839,2012,'01-10-2012','01-10-2013',10,4500,'');
insert into history values (7839,2013,'01-10-2013','01-11-2014',10,4800,'');
insert into history values (7839,2014,'01-11-2014','15-02-2015',10,4900,'');
insert into history values (7839,2015,'15-02-2015',NULL,10,5000,'');
--                          ============================================
insert into history values (7844,2010,'01-05-2010','01-01-2012',30, 900,'');
insert into history values (7844,2013,'15-10-2013','01-11-2013',10,1200,'Project (for half of a month) in the head office');
insert into history values (7844,2013,'01-11-2013','01-01-2015',30,1400,'');
insert into history values (7844,2015,'01-01-2015',NULL,30,1500,'');
--                          ============================================
insert into history values (7876,2015,'01-01-2015','01-02-2015',20, 950,'');
insert into history values (7876,2015,'01-02-2015', NULL,20,1100,'');
--                          ============================================
insert into history values (7900,2015,'01-07-2015', NULL,30, 800,'Junior sales person');
--                          ============================================
insert into history values (7902,2013,'01-09-2013','01-10-2013',40,1400,'');
insert into history values (7902,2013,'01-10-2013','15-03-2014',30,1650,'');
insert into history values (7902,2014,'15-03-2014','01-01-2015',30,2500,'');
insert into history values (7902,2015,'01-01-2015','01-08-2015',30,3000,'');
insert into history values (7902,2015,'01-08-2015', NULL,20,3000,'');
--                          ============================================
insert into history values (7934,2013,'01-02-2013','01-05-2013',10,1275,'');
insert into history values (7934,2013,'01-05-2013','01-02-2014',10,1280,'');
insert into history values (7934,2014,'01-02-2014','01-01-2015',10,1290,'');
insert into history values (7934,2015,'01-01-2015', NULL,10,1300,'');

alter table history enable primary key;

REM ==============================
REM Enable foreign key constraints
REM ==============================

alter table employees enable constraint E_CHIEF_FK;
alter table employees enable constraint E_DEP_FK;
alter table departments enable constraint D_HEAD_FK;
alter table versions enable constraint V_COURSE_FK;
alter table versions enable constraint V_TRAINER_FK;
alter table enrollments enable constraint E_VERS_FK;
alter table enrollments enable constraint E_LEARNER_FK;
alter table history enable constraint H_EMPID_FK;
alter table history enable constraint H_DEP_FK;

REM ============================================
REM Verzamel object-statistics voor de optimizer
REM ============================================

execute dbms_stats.gather_schema_stats(ownname => user, cascade => true);
