-- connect / as sysdba

prompt Drop existing schema ...
drop user student cascade;

prompt Make new schema ...
create user student
-- default tablespace users
-- temporary tablespace temp
identified by oracle;

prompt Grant system privileges
grant create session, alter session,
      unlimited tablespace,
      create table, create view,
      create materialized view,
      create procedure,
      create sequence,
      create synonym,
      create trigger,
      create type
to    student;