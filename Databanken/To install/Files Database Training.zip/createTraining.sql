REM =================
REM Table EMPLOYEES
REM =================

-- drop table employees cascade constraints;

create table employees(
    employeeid NUMBER(4)
    constraint E_PK primary key
    constraint E_EMPID_CHK check (employeeid > 7000),
    lastname VARCHAR2(25) 
    constraint E_LASTNAME_NN not null,
    firstname VARCHAR2(25) 
    constraint E_FIRSTNAME_NN not null,
    service VARCHAR2(20), 
    chief NUMBER(4) 
    constraint E_CHIEF_FK references employees,
    dateOfBirth DATE 
    constraint E_DATEOFBIRTH_NN not null, 
    salary NUMBER(6,2) 
    constraint E_SALARY_NN not null,
    comments NUMBER(6,2),
    department NUMBER(2) default 10,
    constraint M_SALESPERSON_CHK check(decode(service,'SALESPERSON',0,1) + nvl2(comments,1,0) = 1)
);

REM ================
REM Table DEPARTMENTS
REM ================

-- drop table departments cascade constraints;

create table departments(
    departmentid NUMBER(2)
    constraint D_PK primary key
    constraint D_DEPID_CHK check (mod(departmentid,10) = 0),
    name  VARCHAR2(20) 
    constraint D_NAME_NN not null
    constraint D_NAME_UN unique
    constraint D_NAME_CHK check (NAME = upper(NAME)),
    location VARCHAR2(20) 
    constraint D_LOC_NN not null
    constraint D_LOC_CHK check (location = upper(location)), 
    head NUMBER(4)
    constraint D_HEAD_FK references employees
);

alter table employees
add (constraint E_DEP_FK foreign key (department) references departments);

REM =============
REM Table SCALES
REM =============

-- drop table scales cascade constraints;

create table scales(
    scaleid NUMBER(2)
    constraint S_PK primary key,
    lowerLimit NUMBER(6,2) 
    constraint S_LOWERLIMIT_NN not null
    constraint S_LOWERLIMIT_CHK check (lowerLimit >= 0),
    upperLimit NUMBER(6,2) 
    constraint S_UPPERLIMIT_NN not null,
    bonus  NUMBER(6,2) 
    constraint S_BONUS_NN not null, 
    constraint S_LOWER_UPPER check(lowerLimit <= upperLimit)
);

REM ===============
REM table COURSES 
REM ===============

-- drop table courses cascade constraints;

create table courses(
    courseid VARCHAR2(4)  
    constraint C_PK primary key,
    description VARCHAR2(50) 
    constraint C_DESCRIPTION_NN not null,
    type CHAR(3) 
    constraint C_TYPE_NN not null, 
    length NUMBER(2)
    constraint C_LENGTH_NN not null, 
    constraint C_CODE_CHK check (courseid = upper(courseid)),
    constraint C_TYPE_CHK check(type in ('GEN','BLD','DSG'))
);

REM ==================
REM Table VERSIONS
REM ==================

-- drop table versions cascade constraints;

create table versions(
    courseid VARCHAR2(4)
    constraint V_COURSE_NN not null
    constraint V_COURSE_FK references courses,
    startdate DATE
    constraint V_BEGIN_NN not null,
    trainer NUMBER(4)
    constraint V_TRAINER_FK references employees,
    location VARCHAR2(20), 
    constraint V_PK primary key(courseid,startdate)
);

REM ====================
REM Table ENROLLMENTS
REM ====================

-- drop table enrollments cascade constraints;

create table enrollments( 
    learner NUMBER(4)
    constraint E_LEARNER_NN not null
    constraint E_LEARNER_FK references employees, 
    courseid VARCHAR2(4) 
    constraint E_COURSE_NN not null, 
    startdate  DATE
    constraint E_STARTDATE_NN not null,
    evaluation  NUMBER(1)
    constraint E_EVAL_CHK check (evaluation in (1,2,3,4,5)), 
    constraint E_VERS_PK primary key (learner,courseid,startdate), 
    constraint E_VERS_FK foreign key (courseid,startdate) references versions
);

REM ======================================
REM Table HISTORY
REM ======================================

-- drop table  history cascade constraints;

create table history(
    employeeid NUMBER(4) 
    constraint H_EMPID_NN not null
    constraint H_EMPID_FK references employees on delete cascade,
    startyear NUMBER(4)
    constraint H_STARTYEAR_NN not null, 
    startdate DATE
    constraint H_STARTDATE_NN not null, 
    enddate DATE,
    departmentid NUMBER(2)
    constraint H_DEP_NN not null
    constraint H_DEP_FK references departments,
    salary NUMBER(6,2)
    constraint H_SAL_NN not null, 
    remarks VARCHAR2(60),
    constraint  H_PK primary key (employeeid,startdate),
    constraint  H_BEGIN_END check (startdate < enddate)
);
